base = "https://gdbrowser.com/api/"
base_bl = "https://www.boomlings.com/database/"
base_acc = base_bl + "accounts/"
headers = {"User-Agent":""}

